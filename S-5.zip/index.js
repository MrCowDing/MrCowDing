const discord = require('discord-reply');
const { Collection, Client } = require('discord.js');
const { token, default_prefix, config } = require('./config.json');
const Discord = require('discord.js');
Discord.Constants.DefaultOptions.ws.properties.$browser = `Discord iOS`;
const db = require('quick.db');
const { MessageEmbed } = require('discord.js');
const client = new Discord.Client();
const alexa = require('alexa-bot-api');
const fetch = require('node-fetch');
var chatbot = new alexa('aw2plm');
const chatchannel = ['797652650900193291'];
const { readdirSync } = require('fs');
const { join } = require('path');
const { keep_alive } = require('./keep.js');
const fs = require('fs');



client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();




fs.readdir('./command/', (err, files) => {
	if (err) console.log(err);

	let jsfile = files.filter(f => f.endsWith('.js'));
	if (jsfile.length <= 0) {
		return console.log("[LOGS] Couldn't Find Commands!");
	}

	jsfile.forEach((f, i) => {
		let pull = require(`./command/${f}`);
		client.commands.set(pull.config.name, pull);
		pull.config.aliases.forEach(alias => {
			client.aliases.set(alias, pull.config.name);
		});
	});
	client.on('ready', async () => {
		console.log(`${client.user.tag} sudah online!`);

		client.user.setActivity(
			`${default_prefix}Help ┇ ${client.guilds.cache.size} Server`,
			{ type: 3, browser: 'DISCORD IOS' }
		);
	});
});

client.on('messageDelete', async msg => {
	
	const logs = await db.fetch(`logs_${msg.guild.id}`);
	if (logs === null) return;
	if (msg.channel.type === 'dm') return;
	if (msg.author.bot) return;
	let image = msg.attachments.first()
				? msg.attachments.first().proxyURL
				: null
	const embed = new Discord.MessageEmbed()
			.setAuthor(`Deleted`, msg.author.displayAvatarURL())
			.setTitle(`Deleted Message`)
			.setColor('RANDOM')
			.setTimestamp()
			.setDescription([
				`**❯ Message:** ${msg.content}`,
				`**❯ Channel:** ${msg.channel}`,
				`**❯ Author:** ${msg.member.displayName}`
			]);

		if (msg.image) embed.setImage(msg.image).setTimestamp();
		client.channels.cache.get(logs).send(embed);
})

client.on('messageUpdate', async (oldmessage, newmessage) => {
	const logs = await db.fetch(`logs_${oldmessage.guild.id}`);
	if (logs === null) return;
	if (newmessage.author.bot || oldmessage.author.bot) return;
	let embed = new Discord.MessageEmbed()
		.setAuthor(`Edited`, oldmessage.author.displayAvatarURL())
		.setTitle(`Edited Message`)
		.setColor('RANDOM')
		.setTimestamp()
		.setDescription([
			`**❯ Old message:** 
${oldmessage.content}`,
			`**❯ New message:** 
${newmessage.content}`,
			`**❯ Channel:** ${oldmessage.channel}`,
			`**❯ Author:** ${oldmessage.member.displayName}`
		]);
	client.channels.cache.get(logs).send(embed);
})

client.on('message', async message => {
	if (message.content === 'Help') message.channel.send(`do S!help`);
	if (message.content === `<@${client.user.id}>`)
		message.channel.send(`My prefix is **${default_prefix}**`);
	//COMMAND BOT DI SERVER.JS
	let prefix = db.get(`prefix_${message.guild.id}`);
	if (prefix === null) prefix = default_prefix;

	if (message.content.startsWith('s!')) prefix = 's!';

	let blacklist = await db.fetch(`blacklist_${message.author.id}`);

	if (message.author.bot || message.channel.type === 'dm') return;

	if (!message.content.startsWith(prefix)) return null;

	if (blacklist === 'Blacklisted')
		return message.reply('You are blacklisted from the bot!');

	let args = message.content
		.slice(prefix.length)
		.trim()
		.split(' ');
	let cmd = args.shift().toLowerCase();
	let commandfile =
		client.commands.get(cmd) || client.commands.get(client.aliases.get(cmd));
	if (commandfile) {
		commandfile.run(client, message, args);
		client.channels.cache
			.get('803761513306390539')
			.send(`${message.author.tag} menggunakan command ${cmd}`);
	}
});

client.on('message', async message => {
	const chatting = await db.fetch(`chatting_${message.guild.id}`);
	if (chatting === null) return;
	if (message.channel.id === chatting) {
		if (message.author.bot) return;
		if (message.attachments.size > 0) return;

		if (message.content.includes('@here')) return;

		if (message.content.includes('@everyone')) return;
		else {
			fetch(
				`https://api.monkedev.com/fun/chat?msg=${encodeURIComponent(
					message
				)}&uid=000`
			)
				.then(res => res.json())
				.then(async json => {
					return client.channels.cache
						.get(chatting)
						.send(`> ${message}\n${json.response}`); // User Message+Reply
				});
		}
	}
});

client.on('message', async message => {
	if (message.author.bot) return;

	if (db.has(`afk-${message.author.id}+${message.guild.id}`)) {
		const info = db.get(`afk-${message.author.id}+${message.guild.id}`);
		try {
			message.member.setNickname(`${message.author.username}`);
			await message.member.setNickname(`${message.author.username}`);
			await db.delete(`afk-${message.author.id}+${message.guild.id}`);
			message
				.reply(`Your afk status have been removed (${info})`)
				.then(i => i.delete({ timeout: 10000 }));
		} catch (e) {
			await db.delete(`afk-${message.author.id}+${message.guild.id}`);
			message
				.reply(`Your afk status have been removed (${info})`)
				.then(i => i.delete({ timeout: 10000 }));
		}
	}
	//checking for mentions
	if (message.mentions.members.first()) {
		if (
			db.has(`afk-${message.mentions.members.first().id}+${message.guild.id}`)
		) {
			message.channel
				.send(
					message.mentions.members.first().user.tag +
						':' +
						db.get(
							`afk-${message.mentions.members.first().id}+${message.guild.id}`
						)
				)
				.then(i => i.delete({ timeout: 10000 }));
		} else return;
	} else;
});

client.on('message', async message => {
	if (message.author.bot) return;
	let msg = message.content;

	let emojis = msg.match(/(?<=:)([^:\s]+)(?=:)/g);
	if (!emojis) return;
	emojis.forEach(m => {
		let emoji = client.emojis.cache.find(x => x.name === m);
		if (!emoji) return;
		let temp = emoji.toString();
		if (new RegExp(temp, 'g').test(msg))
			msg = msg.replace(new RegExp(temp, 'g'), emoji.toString());
		else msg = msg.replace(new RegExp(':' + m + ':', 'g'), emoji.toString());
	});

	if (msg === message.content) return;

	let webhook = await message.channel.fetchWebhooks();
	let number = randomNumber(1, 2);
	webhook = webhook.find(x => x.name === 'NQN' + number);

	if (!webhook) {
		webhook = await message.channel.createWebhook(`NQN` + number, {
			avatar: client.user.displayAvatarURL({ dynamic: true })
		});
	}

	await webhook.edit({
		name: message.member.nickname
			? message.member.nickname
			: message.author.username,
		avatar: message.author.displayAvatarURL({ dynamic: true })
	});

	message.delete().catch(err => {});
	webhook.send(msg).catch(err => {});

	await webhook.edit({
		name: `NQN` + number,
		avatar: client.user.displayAvatarURL({ dynamic: true })
	});
});
client.login(process.env.TOKEN);
//--------------------------------------------------- F U N C T I O N S --------------------------------------
function randomNumber(min, max) {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
}
