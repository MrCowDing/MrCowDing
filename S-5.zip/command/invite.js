const { MessageEmbed } = require('discord.js')

module.exports.run = async (client, message, args) => {
 
  let embed = new MessageEmbed()
  .setTitle(`Invite Sans Bot`)
  .setDescription(`[INVITE ME THEN](https://discord.com/oauth2/authorize?client_id=774575170954067968&scope=bot&permissions=2081287408)`)
  .setColor("RANDOM")
  
  message.channel.send(embed)
}
module.exports.config = {
  name: 'invite',
  aliases: ['inv']
    
}