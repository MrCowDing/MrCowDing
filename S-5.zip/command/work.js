const db = require('quick.db');
const dc = require('discord.js');
const ms = require('parse-ms');
const prem = require('../premium.json')

module.exports.run = async (client, message, args) => {
	
	const pr = [prem]

	let job = db.get(`job_${message.author.id}`);
	let fw = Math.floor(Math.random() * 2) + 1;
	let salary = parseInt(db.get(`salary_'${job}'`));
	
	let w = db.get(`wp_${message.author.id}`);
	{
		if (!args[0]) {
			if (job === null) {
				return message.channel.send(
					'**Wdym you not have job! do S! job list!**'
				);
} else {
				let lel = new dc.MessageEmbed()
					.setAuthor(`Work`, message.author.displayAvatarURL())
					.setDescription(`You are now work as ${job} `)
					.setTimestamp()
					.setColor('GREEN');
				const lol = await message.channel.send(lel);

				setTimeout(() => {
					let lel1 = new dc.MessageEmbed()
						.setAuthor(`Work`, message.author.displayAvatarURL())
						.setDescription(
							`You have finished try to be as ${job}, and received a salary of ${salary} Gems`
						)
						.setTimestamp()
						.setColor('GREEN');
					db.add(`money_${message.author.id}`, salary);
					db.add(`wp_${message.author.id}`, 1);
					lol.edit(lel1);
				}, 10000);
			}
		}
	}

	if (args[0] === 'employees') {
		db.set(`job_${message.author.id}`, `employees`);
		return message.channel.send(`You try to be **employees**`);
	}
	if (args[0] === 'chef') {
		if (w < 15) {
			return message.channel.send(
				`**Hey you dont have enough __work points__ go work!**`
			);
		} else {
			db.set(`job_${message.author.id}`, `chef`);
			return message.channel.send(`You try to be **chef**`);
		}
	}
	if (args[0] === 'coder') {
		if (w < 30) {
			return message.channel.send(
				`**Hey you dont have enough __work points__ go work!**`
			);
		} else {
			db.set(`job_${message.author.id}`, `coder`);
			return message.channel.send(`You try to be **coder**`);
		}
	}
if (args[0] === 'developer') {
		if (w < 60) {
			return message.channel.send(
				`**Hey you dont have enough __work points__ go work!**`
			);
		} else {
			db.set(`job_${message.author.id}`, `developer`);
			return message.channel.send(`You try to be **developer**`);
		}
	}
if (args[0] === 'scientist') {
		if (w < 105) {
			return message.channel.send(
				`**Hey you dont have enough __work points__ go work!**`
			);
		} else {
			db.set(`job_${message.author.id}`, `scientist`);
			return message.channel.send(`You try to be **scientist**`);
		}
	}
if (args[0] === 'pilot') {
		if (w < 150) {
			return message.channel.send(
				`**Hey you dont have enough __work points__ go work!**`
			);
		} else {
			db.set(`job_${message.author.id}`, `pilot`);
			return message.channel.send(`You try to be **pilot**`);
		}
	}	

	if (args[0] === 'info') {
		if (job === null) job = 'Poor man';
		if (job === null) salary = 0;
		if (w === null) w = 0;

		let info = new dc.MessageEmbed()
			.setAuthor(`${message.author.username} Job`)
			.setColor('RANDOM')
			.setThumbnail(message.author.displayAvatarURL())
			.setDescription(`**Job :** ${job}
**Salary :** ${salary.toLocaleString()} Gems
**Work Points :** ${w}`);
		message.channel.send(info);
	}

	if (args[0] === 'list') {
		if (!args[1] || args[1] === '1') {
			let list = new dc.MessageEmbed()
				.setTitle(`Job List`)
				.setColor('RANDOM')
				.addField(' employees ┇ 0 point', 'Salary : 50 or 100 Gems')
				.addField(' chef ┇ 15 points', 'Salary : 250 or 500 Gems')
				.addField(' coder ┇ 30 points', 'Salary : 500 or 1000 Gems')
				.addField(' developer ┇ 60 point', 'Salary : 1050 or 2100 Gems')
				.addField(' scientist ┇ 105 points', 'Salary : 1710 or 3420 Gems')
				.addField(' pilot ┇ 150 points', 'Salary : 2250 or 4500 Gems')
				.setFooter('Type S!work (job) - to get the job')
				.setTimestamp();
			message.channel.send(list);
		}
	}
	db.set(`salary_'employees'`, 100);
	db.set(`salary_'chef'`, 500);
	db.set(`salary_'coder'`, 1000);
  db.set(`salary_'developer'`, 2100)
  db.set(`salary_'scientist'`, 3420)
  db.set(`salary_'pilot'`, 4500)


}
module.exports.config = {
 name: 'work',
	aliases: ['wr', 'wrok', 'job', 'wokr', 'w', 'j', 'wkro'] 
};
