module.exports.run = async (client, message, args) => {
  
const dc = require ('discord.js')
  
  let y = new dc.MessageEmbed()
  .setTitle(`INFO THIS BOT`)
  .setColor('RANDOM')
  .setThumbnail(client.user.displayAvatarURL())
  .addField('⚙️ Made by', '`Couo Gan😎#8203 Newbie CODER`')
  .addField('🔧 Developed by', '`NINJA PEACE#3661 AND Couo Gan😎#8203#7540`') 
  .addField('☕ Thank`s to', '`NINJA PEACE#3661 For Help Me`')
  .addField('CREDIT', '`Hi im SANS BOT, I was made to help out with everything. maybe some commands are missing, but I hope you like it.`')
  
  message.channel.send(y);

  
}  
module.exports.config = {
  name: 'info',
  aliases: []
  }