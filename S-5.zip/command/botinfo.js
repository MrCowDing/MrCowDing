const db = require("quick.db");
const Discord = require ("discord.js")
const { version } = require('../package.json');
const ms = require('pretty-ms');
const { version: discordjsVersion } = require('discord.js');

module.exports.run = async(client, message, args) => { 

  
      message.channel.send(new Discord.MessageEmbed()
            .setColor('RANDOM')
            .setTitle(`Sans v${version}`)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .addField('Uptime', `${ms(client.uptime)}`, true)
            .addField('WebSocket Ping', `${client.ws.ping}ms`, true)
            .addField('Memory', `${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB RSS\n${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB Heap`, true)
            .addField('Guild Count', `${client.guilds.cache.size} guilds`, true)
            .addField(`Developer`, `3 dev`, true)
            .addField('Commands', `${client.commands.size} cmds`,true)
            .addField('Node', `${process.version} on @repl.it `, true)
            .addField('Cached Data', `${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)} users\n${client.emojis.cache.size} emojis`, true)
            .addField('Discord.js', `${discordjsVersion}`, true)
            .setTimestamp()
        );
    }
module.exports.config = {
  name: 'botinfo',
  aliases: ['uptime', 'bstats',]
}