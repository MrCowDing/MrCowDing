module.exports.run = async (client, message, args) => {
	const db = require('quick.db');
	const dc = require('discord.js');

	const content = args.join(' ');
	
	try {
		message.member.setNickname(`[AFK] ${message.author.username}`);
		db.set(`afk-${message.author.id}+${message.guild.id}`, content);
		const embed = new dc.MessageEmbed()
			.setDescription(`You have been set to afk\n**Reason :** ${content}`)
			.setColor('RANDOM')
			.setAuthor(
				message.author.tag,
				message.author.displayAvatarURL({ dynamic: true })
			);
		message.channel.send(embed);
	} catch(e) {
	  db.set(`afk-${message.author.id}+${message.guild.id}`, content);
		const embed = new dc.MessageEmbed()
			.setDescription(`You have been set to afk\n**Reason :** ${content}`)
			.setColor('RANDOM')
			.setAuthor(
				message.author.tag,
				message.author.displayAvatarURL({ dynamic: true })
			);
	}
};
module.exports.config = {
	name: 'afk',
	aliases: ['a']
};
