module.exports.run = async(client,message,args) => {

let owners = "575558325832253440"
if(!owners.includes(message.author.id)) return;
message.channel.send("Restarting.......").then((n) => {
client.destroy()
setTimeout(() => {
	client.login(process.env.token)
	n.edit("System Restarted :white_check_mark:")
	}, 20000)
})
}
module.exports.config ={
  name: 'restart',
  aliases: []
}