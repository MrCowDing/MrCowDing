const config = require("../config.json")
const Discord = require("discord.js")


module.exports.run = async (client, message, args) => {
  
const owners = ["575558325832253440","767539975553024041","763546186463576072"]

  if (! owners.includes(message.author.id)) {
return message.channel.send("Sorry this command just can use by **dev** or **higher**")
  } 
  
 const toEval = args.join(" ")
 const evaluated = eval(toEval)
 const type = typeof(evaluated)
 
 let embed = new Discord.MessageEmbed()
 .setColor("RANDOM")
 .setTimestamp()
 .setFooter(`evaled`)
 .setTitle("Eval")
 .addField("**To eval:**", `\`\`\`kt\n${toEval}\n\`\`\``)
 .addField("**Evaluated:**", `\`\`\`kt\n${evaluated}\n\`\`\``)
 .addField("**type**", `\`\`\`kt\n${type}\n\`\`\``)

message.channel.send(embed);


}
module.exports.config = {
  name: 'eval',
  aliases: ['ev']
}