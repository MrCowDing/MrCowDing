const { Canvas } = require("discord-utils.js")
const level = "1000"
module.exports.run = async (client, message, args) => {
let user = message.mentions.users.first() || message.author
let avatar = user.displayAvatarURL()
let image = await Canvas.magik(avatar, level)
message.channel.send({
files: [{
name: "image.png",
attachment: image
}]
})
}
module.exports.config = {
	name: 'magiktest',
  aliases: ['magic,curse']
}