
const { MessageEmbed, MessageAttachment } = require('discord.js');
const { Canvas } = require("canvacord")
module.exports.run = async(client, message, args) => {
        const words= args.join(" ")

        const img = await Canvas.ohno(words)

        message.channel.send(
            new MessageAttachment(img, "ohno.png")
        )
    }
module.exports.config = {
	name: 'ohno',
  aliases: []
}
