module.exports.run = async(client, message, args) => {

const dc = require("discord.js")
const db = require("quick.db")

    const msg = client.snipes.get(message.channel.id)
    if(!msg) return message.channel.send("There are no deleted messages in this channel!")
    const embed = new dc.MessageEmbed()
    .setAuthor(msg.author)
    .setDescription(msg.content)
    if(msg.image)embed.setImage 
      (msg.image)
    .setFooter('Get Sniped lol')
    .setTimestamp();
    message.channel.send(embed);

}
module.exports.config = {
  name: 'snipe',
  aliases: ['ms']
}