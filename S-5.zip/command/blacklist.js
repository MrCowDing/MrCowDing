const Discord = require('discord.js')
const db = require('quick.db')

 module.exports.run = async(client, message, args) => {
 
    const owners = ["575558325832253440","767539975553024041","763546186463576072"]

  if (! owners.includes(message.author.id)) {
return message.channel.send("Sorry this command just can use by **dev** or **higher**")
  } 
   
   
   
    const user = message.mentions.users.first()
    if (!user) return message.reply("Please mention someone!")
    
    let blacklist = await db.fetch(`blacklist_${user.id}`)
    
    if (blacklist === "Not") {
      db.set(`blacklist_${user.id}`, "Blacklisted") 
      let embed = new Discord.MessageEmbed()
      .setDescription(`${user} has been blacklisted!`)
      
      message.channel.send(embed)
    } else if (blacklist === "Blacklisted") {
       db.set(`blacklist_${user.id}`, "Not") 
      let embed = new Discord.MessageEmbed()
      .setDescription(`${user} has been unblacklisted!`)
      
      message.channel.send(embed)
    } else {
       db.set(`blacklist_${user.id}`, "Not") 
      let embed = new Discord.MessageEmbed()
      .setDescription(`Set up data for ${user}!`)
      
      message.channel.send(embed)
    }
  }
module.exports.config = {
 name : 'blacklist',
 aliases : ['bl']
}