const discord = require("discord.js")
const { NovelCovid } = require("novelcovid");
const track = new NovelCovid();

module.exports.run = async (client, message, args) => {

 
    
    if(!args.length) {
      return message.channel.send("Please give the name of country")
    }
    
    if(args.join(" ") === "all") {
      let corona = await track.all() //it will give global cases
      
      let embed = new discord.MessageEmbed()
      .setTitle("Global Cases")
      .setColor("RANDOM")
      .setDescription("Sometimes cases number may differ from small amount.")
      .setThumbnail('https://i.giphy.com/YPbrUhP9Ryhgi2psz3.gif')
      .addField('Total Cases', 
      corona.cases.toLocaleString(), true)
      .addField('Total Deaths', 
      corona.deaths.toLocaleString(), true)
      .addField('Total Recovered',
      corona.recovered.toLocaleString(), true)
      .addField('Today Cases', 
      corona.todayCases.toLocaleString(), true)
      .addField('Today Deaths', 
      corona.todayDeaths.toLocaleString(), true)
      .addField('Active Cases', 
      corona.active.toLocaleString(), true);
      
      return message.channel.send(embed)
      
      
      
    }else {
      let corona = await track.countries(args.join(" ")) //change it to countries
      
      let embed = new discord.MessageEmbed()
      .setTitle(`${corona.country}`)
      .setColor("RANDOM")
      .setDescription("Sometimes cases number may differ from small amount.")
      .setThumbnail(args[0] ? corona.countryInfo.flag : 'https://i.giphy.com/YPbrUhP9Ryhgi2psz3.gif')
      .addField('Total Cases', 
      corona.cases.toLocaleString(), true)
      .addField('Total Deaths', 
      corona.deaths.toLocaleString(), true)
      .addField('Total Recovered', 
      corona.recovered.toLocaleString(), true)
      .addField('Todays Cases',
      corona.todayCases.toLocaleString(), true)
      .addField('Todays Deaths',
      corona.todayDeaths.toLocaleString(), true)
      .addField('Active Cases', 
      corona.active.toLocaleString(), true);
      
      return message.channel.send(embed)
      
      
    }
}
    
    module.exports.config = {
      name: 'covid',
      aliases: ['cov','cor','corona']
    }