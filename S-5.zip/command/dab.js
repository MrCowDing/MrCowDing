const {
  MessageEmbed,
  MessageAttachment
} = require("discord.js");

const Meme = require("memer-api");
const memer = new Meme();

module.exports.run = async (client, message, args) => {
      //send loading message
      var tempmsg = await message.channel.send(new MessageEmbed()
        .setColor("RANDOM")
        .setAuthor("Getting Image Data..", "https://images-ext-1.discordapp.net/external/ANU162U1fDdmQhim_BcbQ3lf4dLaIQl7p0HcqzD5wJA/https/cdn.discordapp.com/emojis/756773010123522058.gif")
      );
      //get pinged user, if not then use cmd user
      var user = message.mentions.users.first() || message.author;
      //get avatar of the user
      var avatar = user.displayAvatarURL({ format: "png" });
      //get the memer image
      memer.dab(avatar).then(image => {
        //make an attachment
        var attachment = new MessageAttachment(image, "dab.png");
        //delete old message
        tempmsg.delete();
        //send new Message
        message.channel.send(tempmsg.embeds[0]
          .setAuthor(`Meme for: ${user.tag}`, avatar)
          .setImage("attachment://dab.png")
          .attachFiles(attachment)
        ).catch(e => console.log("Couldn't delete msg, this is for preventing a bug".gray))
      })
      
  }
module.exports.config = {
	name: 'dab',
  aliases: []
}