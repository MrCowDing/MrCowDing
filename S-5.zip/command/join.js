const { MessageEmbed } = require('discord.js')

module.exports.run = async (client, message, args) => {
  
  let embed = new MessageEmbed()
  .setTitle(`Join to official sans bot server`)
  .setDescription(`[Join official Server](https://discord.gg/hXFRudGurd)`)
  .setColor("RANDOM")
  
  message.channel.send(embed)
}
module.exports.config = {
  name: 'join',
  aliases: []
    
}