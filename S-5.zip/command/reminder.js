require("discord-reply")
const { Client, Message, MessageEmbed } = require('discord.js');
const ms = require("ms")

module.exports.run = async(client, message, args) => {
    
    let user =
		message.mentions.users.first() ||
		message.author ||
		message.guild.members.cache.get(args[0]).user;
     
        
       const a = message.client.emojis.cache.get('829916402386337812')
  
  const b = message.client.emojis.cache.get('766844029497245756')

        
        let time = args[0]
        if(!time) return message.channel.send("What is the time when the reminder should be off?")
        if(ms(time) > ms("1w")) return message.lineReply(`You cannot set your reminder for more than 1w`)

        let alert = args.slice(1).join(" ")
        if(!alert) return message.channel.send(`What is reminder for?`)
        let embed = new MessageEmbed()
        .setTitle(`${a} Your reminder has been set! ${a}`, user.displayAvatarURL())
        .setColor("RANDOM")
        .addField(`Time:`, `\`${time}\``, true)
        .addField(`For:`, `\`${alert}\``, true)
        message.lineReplyNoMention(embed)
        setTimeout(() => {
            let DP = new MessageEmbed()
            .setTitle(`${b} Your reminder is off! ${b}`)
            .setColor("RANDOM")
            .addField("Duration", `\`${time}\``, true)
            .addField(`Reason:`, `\`${alert}\``, true)
            message.lineReply(DP)
        }, ms(time))
}
module.exports.config = {
	name: 'reminder',
  aliases: ['rm']
}