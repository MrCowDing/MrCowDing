const dc = require('discord.js')

module.exports.run = async (client, message, args) => {
  
  const emoji = message.client.emojis.cache.get('803766094220754954')
  
  const emo = message.client.emojis.cache.get('803842146695643166')
  
  const emoj = message.client.emojis.cache.get ('803840325940019211')
  
  const em = message.client.emojis.cache.get('804089878069116939')
  
  const utility = message.client.emojis.cache.get('766844029497245756')
  
  const meme = message.client.emojis.cache.get('836070689831256065')
  
  let y = new dc.MessageEmbed()
  .setTitle(`SANS BOT Commands`)
  .setColor('RANDOM')
  .addField(`${emoji}┇Economy`,'`balance`, `daily`, `deposit`, `hourly`, `withdraw`, `work`, `pay`')
  .addField(`${meme}┇Image`,'`abandon`, `achievement`, `affect`, `airpods`, `armor`, `avatar`, `bed`, `brazzer`, `byemom`, `cancer`, `changemymind`,`communism`,`corporate`, `cry`, `dab`, `door`, `disability`, `magik`, `ohno`, `quote`, `shit`, `trash`, `wasted`') 
  .addField(`${emo}┇Utility`,'`animesearch`, `afk`, `botinfo`, `calculate`, `covid`, `docs`, `github`, `info`, `playstore`, `npm`, `reminder`, `transalate`, `webss`, `wiki`')
   .addField(`${emoj}┇ Moderation`, '`chat`, `clear`, `nuke`, `prefix`, `modlogs`,')
  
   

  message.channel.send(y)
}
module.exports.config = {
  name: 'help',
  aliases: ['h']
    
    }