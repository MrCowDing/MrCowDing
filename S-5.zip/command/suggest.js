/* { MessageEmbed } = require("discord.js");
const Discord = require("discord.js");
module.exports = {
  name: "report",
  category: "everyone",
  usage: "?report <Message>",
  description: "simple report command",
   run: async (client, message, args) => {
  if(!args[0]) {
      return message.channel.send("Please type something to report!")
    }

  const channel = await client.channels.fetch("Channel ID here")
    let embed = new Discord.MessageEmbed()
.setColor(`RANDOM`)
.setTitle("NEW REPORT!")
.setDescription(args.slice(0).join(" "))
.setFooter(`Reported by: ${message.author.username}`)

return channel.send(embed)
message.channel.send("Report sent!")
     
  }
};
*/

const { MessageEmbed } = require("discord.js")
const dc = require("discord.js");
module.exports.run = async(client, message, args) => {
let bug = args.join(" ").slice(0);
let user = message.author.username;
let guild = message.guild.name;
let channel = await client.channels.fetch("816178025708126209")
let embed = new dc.MessageEmbed()
.setTitle("Bug Report")
.setThumbnail("https://images-ext-1.discordapp.net/external/nQoe_5zRdR6A5gsh2fevRbNvhoc5A2YIWP7zVdN5_NE/%3Fv%3D1/https/cdn.discordapp.com/emojis/435908220100280320.png?width=80&height=80")
.addField("Suggest", bug)
.addField("Suggest By", user)
.addField("Suggest in", guild)
.setColor("RANDOM")

message.channel.send("**| Your bug has been reported in the official server. It will be reviewed so please be patient.**")
channel.send(embed).then(i => i.react("⏳"))

}
module.exports.config = {
  name: 'suggest',
  aliases: ['']
}