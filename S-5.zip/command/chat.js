module.exports.run = async(client, message, args) => {


const dc = require('discord.js');
const db = require('quick.db');

  if (!message.member.permissions.any(["MANAGE_GUILD", "ADMINISTRATOR"])) {
      return message.channel.send("You don't have permissions to do this.");
  }
  
  let toggling = ["disable","enable"];
  if (!toggling.includes(args[0])) {
      return message.channel.send("Please select **enable** or **disable**, ok? ")
  }
  
  if (args[0] === "enable") {
      let channel = message.mentions.channels.first();
      if (!channel) return message.channel.send("Please ping the channel that you want to make it as an chatbot...");
  
      await db.set
        (`edit_${message.guild.id}`, channel.id)
      await db.set(`chatting_${message.guild.id}`, channel.id)
      message.channel.send(`succesfully enable chat in <#${channel.id}>`);
   }
  
  if (args[0] === "disable") {
    let toggle = db.fetch(`chatting_${message.guild.id}`)
    if (!toggle) return message.channel.send("u have disabled logging before.");
    
    await db.delete
      (`edit_${message.guild.id}`)
    await db.delete(`chatting_${message.guild.id}`)
    message.channel.send(`Succesfully disable chat.`);

  }
}
 module.exports.config = {
  name: 'chat',
  aliases: ['cb']
  }